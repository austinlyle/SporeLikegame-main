
package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Actor;

//Actor class for an enemy circle
// No user input

    public class EnemyActor extends Actor {
        Sprite sprite = new Sprite (new Texture(Gdx.files.internal("enemycircle.png")));

        public EnemyActor() {}




        @Override
        protected void positionChanged() {
            sprite.setPosition(getX(),getY());
            super.positionChanged();
        }

        @Override
        public void draw(Batch batch, float parentAlpha) {
            //Starting Pos
            sprite.setPosition(200,200);
            //Actor Scale
            sprite.setScale(.5f);
            sprite.draw(batch);
        }

        @Override
        public void act(float delta) {
            super.act(delta);
        }
    }


