package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.actions.MoveByAction;

//
//Actor Class for the players Circle, takes users input

public class MyActor extends Actor {

    Sprite sprite = new Sprite (new Texture(Gdx.files.internal("playercircle.png")));
    boolean moveRight = false;
    boolean moveLeft = false;
    boolean moveUp = false;
    boolean moveDown = false;

    public MyActor() {

        setBounds(sprite.getX(), sprite.getY(), sprite.getWidth(), sprite.getHeight());
        setTouchable(Touchable.enabled);




        addListener(new InputListener() {
            @Override
            public boolean keyDown(InputEvent event, int keycode) {

                if (keycode == Input.Keys.RIGHT) {

                    MoveByAction mba = new MoveByAction();
                    mba.setAmount(5f, 0f);
                    MyActor.this.addAction(mba);

                }



                if (keycode == Input.Keys.LEFT) {
                    MoveByAction mba = new MoveByAction();
                    mba.setAmount(-5f, 0f);

                    MyActor.this.addAction(mba);

                }
                if (keycode == Input.Keys.UP) {
                    MoveByAction mba = new MoveByAction();
                    mba.setAmount(0f, 5f);

                    MyActor.this.addAction(mba);

                }
                if (keycode == Input.Keys.DOWN) {
                    MoveByAction mba = new MoveByAction();
                    mba.setAmount(0f, -5f);

                    MyActor.this.addAction(mba);
                }

                return false;
            }
            @Override
            public boolean keyUp(InputEvent event, int keycode) {
                if (keycode == Input.Keys.RIGHT) {

                    MoveByAction mba = new MoveByAction();
                    mba.setAmount(5f, 0f);

                    MyActor.this.addAction(mba);
                    return true;


                }
                if (keycode == Input.Keys.LEFT) {
                    MoveByAction mba = new MoveByAction();
                    mba.setAmount(-5f, 0f);

                    MyActor.this.addAction(mba);

                }
                if (keycode == Input.Keys.UP) {
                    MoveByAction mba = new MoveByAction();
                    mba.setAmount(0f, 5f);

                    MyActor.this.addAction(mba);

                }
                if (keycode == Input.Keys.DOWN) {
                    MoveByAction mba = new MoveByAction();
                    mba.setAmount(0f, -5f);

                    MyActor.this.addAction(mba);
                }

                return true;
            }

        });

    }

    @Override
    protected void positionChanged() {
        sprite.setPosition(getX(),getY());
        super.positionChanged();
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        sprite.setScale(.5f);
        sprite.draw(batch);
    }

    @Override
    public void act(float delta) {
        super.act(delta);
    }
}
