package com.mygdx.game;

public class Collision {

    public static void main(String args[]){



    }
}
