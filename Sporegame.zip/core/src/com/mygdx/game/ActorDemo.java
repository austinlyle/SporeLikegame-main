package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;



public class ActorDemo extends ApplicationAdapter {

	Stage stage;

	@Override
	public void create () {

		ScreenViewport viewport = new ScreenViewport();
		stage = new Stage(viewport);
		Gdx.input.setInputProcessor(stage);


		//Makes new object from the background class
		//Just a jpg with a blue gradient
		//Must be called first or it will be drawn ontop of all other actors
		BackgroundActor background = new BackgroundActor();
		stage.addActor(background);


		//Makes new object from enemy actor and passes it to the stage
		EnemyActor enemyActor = new EnemyActor();
		stage.addActor(enemyActor);

		//Makes new object from player actor and passes it to stage
		MyActor playerActor = new MyActor();
		stage.addActor(playerActor);
		stage.setKeyboardFocus(playerActor); //passes keyboard events to player actor


		//Makes a new circle object and passes the PLAYER ACTORS
		//height and width as x and y
		//and the radius as half the width
		Circle playerCirc = new Circle();
		playerCirc.setX(playerActor.getHeight());
		playerCirc.setY(playerActor.getWidth());
		playerCirc.setRadius(playerActor.getWidth()/2);

		//Makes a new circle object and passes the ENEMY ACTORS
		//height and width as x and y
		//and the radius as half the width
		Circle enemyCirc = new Circle();
		playerCirc.setX(enemyActor.getHeight());
		playerCirc.setY(enemyActor.getWidth());
		playerCirc.setRadius(enemyActor.getWidth()/2);







	}
	//Collision detection?
	public boolean isCirclesColliding(Circle cir1, Circle cir2) {
		float sidea = Math.abs(cir1.x - cir2.x);
		float sideb = Math.abs(cir1.y - cir2.y);
		sidea = sidea * sidea;
		sideb = sideb * sideb;
		float distance = (float) Math.sqrt(sidea + sideb);
		if (distance < cir1.radius + cir2.radius) {
			System.out.println("Collision");
			return true;
		}
			return false;

	}

	@Override
	public void render () {
		ScreenUtils.clear(1, 1, 1, 1);
		stage.act(Gdx.graphics.getDeltaTime());
		stage.draw();
		//Call collision detection, giving it enemy and player circles
		//NOT WORKING, can't see parameters due to them being outside this method
		//isCirclesColliding(playerCirc, enemyCirc);
	}
	
	@Override
	public void dispose () {
		stage.dispose();
	}
}
